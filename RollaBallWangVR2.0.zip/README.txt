Github Link: https://github.com/39xdgy/RollABallWang

Contributors: Anthony Delgado, Salem Ozaki, Jiashu Wang.

Anthony:
I implemented the ball respawn/reset at the user's feet.
I also implemented the ability for the user to pick up the ball and shoot it in the direction that the controller is pointed.


Salem:
If you press the grip on the left controller, you will turn off the gravity for the ball.  If the gravity is turned off, then the left grip will turn on the gravity again.

Jiashu:
I implemented that the ball will jump when the right grip button is pressed. The height of the jump is a public value that people can change inside Unity. 

Button list:
Left touchpad pressdown: teleport
Right touchpad: ball movement
Left Grip: Gravity switch
Right Grip: Jump
Grab object: either trigger
Shooting: grab the object and pres the touchpad down